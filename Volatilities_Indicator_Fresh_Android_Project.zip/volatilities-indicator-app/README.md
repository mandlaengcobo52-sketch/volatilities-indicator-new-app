# Volatilities Indicator Android App

Fresh Android project foundation for the new Volatilities Indicator application.

Build requirements:
- JDK 17
- Gradle 8.9+
- Android SDK 35
- Kotlin JVM target 17

This project intentionally starts clean. Trading, Admin/User surfaces, Deriv direct API execution, SMC/HPA/PTPE, and other project modules will be added in controlled stages after the base APK build is confirmed.
