package za.co.volatilitiesindicator.app

import android.os.Bundle
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.ComponentActivity

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 48, 32, 32)
        }

        val title = TextView(this).apply {
            text = "VOLATILITIES INDICATOR"
            textSize = 26f
            setTypeface(null, android.graphics.Typeface.BOLD)
        }

        val subtitle = TextView(this).apply {
            text = "\nNEW ANDROID APP\n\nFresh project foundation\nJava 17 • Kotlin 17 • Android SDK 35"
            textSize = 18f
        }

        root.addView(title)
        root.addView(subtitle)
        setContentView(root)
    }
}
