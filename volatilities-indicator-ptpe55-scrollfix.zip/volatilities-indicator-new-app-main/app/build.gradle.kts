plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "za.co.volatilitiesindicator.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "za.co.volatilitiesindicator.app"
        minSdk = 24
        targetSdk = 35
        versionCode = 1
        versionName = "1.0.0"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }
}

kotlin {
    jvmToolchain(17)
}
dependencies {
    implementation("com.squareup.okhttp3:okhttp:4.12.0")
}
